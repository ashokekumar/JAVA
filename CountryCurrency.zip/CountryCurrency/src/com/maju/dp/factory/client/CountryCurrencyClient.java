/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maju.dp.factory.client;

import com.maju.countrytocurrency.abstractfactory.Currency;
import java.util.Scanner;

/**
 *
 * @author Ashoke.Kumar
 */


public class CountryCurrencyClient {

    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        int i=0;
        while (i<3){
        
        Scanner input = new Scanner(System.in);        
        System.out.print("Enter a country name: ");
        String Countryname = input.next();//take input country name from user
        
        Currency currency = CurrencyProducer.createCurrency(Countryname);
        if(currency!=null)
        System.out.println(currency.getCurrency());  
        else System.out.println("No Currency Found");
        i++;
       }   
     
    }
    
}
