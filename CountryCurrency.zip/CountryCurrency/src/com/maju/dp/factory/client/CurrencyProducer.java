/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maju.dp.factory.client;

import com.maju.countrytocurrency.abstractfactory.Currency;
import com.maju.countrytocurrency.abstractfactory.factories.PakistanFactory;
import com.maju.countrytocurrency.abstractfactory.factories.SaudiArabiaFactory;
import com.maju.countrytocurrency.abstractfactory.factories.USFactory;

/**
 *
 * @author Ashoke.Kumar
 */
public class CurrencyProducer {
    
    private CurrencyProducer(){}
    public static Currency createCurrency( String inputCountry){
    
        String[] Country = new String[]{"Pakistan","Saudiarbia","US"};
        //String Country = null;
        //Country[0] ="Pakistan";
       // String inputCountry ="Pakistan";
        
        if(inputCountry.equalsIgnoreCase(Country[0])){
            return new PakistanFactory().createCurrency();
        }
        else if(inputCountry.equalsIgnoreCase(Country[1]))
        {
         return new SaudiArabiaFactory().createCurrency();
        }
        else if(inputCountry.equalsIgnoreCase(Country[2]))
        {
         return new USFactory().createCurrency();
        }
        return null;
    }
}