/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maju.countrytocurrency.abstractfactory.factories;

import com.maju.countrytocurrency.abstractfactory.Currency;
import com.maju.countrytocurrency.abstractfactory.USCurrency;

/**
 *
 * @author Ashoke.Kumar
 */
public class USFactory implements CountryFactory{
    @Override
    public Currency createCurrency() {
        System.out.println("Create Currency Factory US...");
        return new USCurrency();
    }
}
